<div id="mainWrapper">
        <div id="ribbon" class="dhtmlxribbon_dhx_skyblue" style="height: 27px;"><div class="dhxrb_with_tabbar dhxtabbar_base_dhx_skyblue"><div class="dhxtabbar_cont" style="left: 0px; width: 1000px; top: 0px; height: 117px;"><div class="dhxtabbar_tabs_top"><div class="dhxtabbar_tabs dhxtabbar_tabs_top" style="top: 0px; width: 998px;"><div class="dhxtabbar_tabs_ar_left"><div class="dhxtabbar_arrow_img"></div></div><div class="dhxtabbar_tabs_base" style="left: 14px; width: 970px;"><div class="dhxtabbar_tabs_cont_left" style="left: 0px; transition: left 0.15s ease 0s;"><div class="dhxtabbar_tabs_line"></div><div class="dhxtabbar_tab dhxtabbar_tab_actv" style="width: 59px;"><div class="dhxtabbar_tab_text">SMS</div></div><div class="dhxtabbar_tab" style="width: 62px;"><div class="dhxtabbar_tab_text">Push</div></div><div class="dhxtabbar_tab" style="width: 56px;"><div class="dhxtabbar_tab_text">Pull</div></div><div class="dhxtabbar_tab" style="width: 72px;"><div class="dhxtabbar_tab_text">Report</div></div></div></div><div class="dhxtabbar_tabs_ar_right"><div class="dhxtabbar_arrow_img"></div></div></div><div class="dhx_cell_tabbar" style="visibility: visible; z-index: 1; left: 0px; top: 27px; width: 1000px; height: 90px;"><div class="dhx_cell_cont_tabbar" style="left: 0px; top: 0px; width: 998px; height: 90px;"><div class="dhxrb_g_area"><div class="dhxrb_block_base"><div class="dhxrb_block_items"><div class="dhxrb_big_button"><img class="dhxrb_image" src="vas/sms/images/load/sendsms.png"><div class="dhxrb_label_button">Send SMS</div></div></div><div class="dhxrb_block_label">send sms</div></div><div class="dhxrb_block_base"><div class="dhxrb_block_items"><div class="dhxrb_big_button"><img class="dhxrb_image" src="vas/sms/images/load/adressbook.png"><div class="dhxrb_label_button">Address Book</div></div></div><div class="dhxrb_block_label">contacts</div></div><div class="dhxrb_block_base"><div class="dhxrb_block_items"><div class="dhxrb_big_button"><img class="dhxrb_image" src="vas/sms/images/load/scheduler.png"><div class="dhxrb_label_button">Scheduler</div></div></div><div class="dhxrb_block_label">scheduler</div></div><div class="dhxrb_block_base"><div class="dhxrb_block_items"><div class="dhxrb_big_button"><img class="dhxrb_image" src="vas/sms/images/load/save_msg.png"><div class="dhxrb_label_button">Messages</div></div></div><div class="dhxrb_block_label">Messages</div></div><div class="dhxrb_block_base"><div class="dhxrb_block_items"><div class="dhxrb_big_button"><img class="dhxrb_image" src="vas/sms/images/load/template.png"><div class="dhxrb_label_button">Templates</div></div></div><div class="dhxrb_block_label">template</div></div></div></div></div><div class="dhx_cell_tabbar" style="visibility: hidden; z-index: 0; left: 0px; top: -5000px; width: 1000px; height: 90px;"><div class="dhx_cell_cont_tabbar" style="left: 0px; top: 0px; width: 998px; height: 90px;"><div class="dhxrb_g_area"><div class="dhxrb_block_base"><div class="dhxrb_block_items"><div class="dhxrb_big_button"><img class="dhxrb_image" src="vas/sms/images/load/cron.png"><div class="dhxrb_label_button">Que Jobs</div></div></div><div class="dhxrb_block_label">Que</div></div><div class="dhxrb_block_base"><div class="dhxrb_block_items"><div class="dhxrb_big_button"><img class="dhxrb_image" src="vas/sms/images/load/gateway.png"><div class="dhxrb_label_button">Gateway</div></div></div><div class="dhxrb_block_label">gateway</div></div><div class="dhxrb_block_base"><div class="dhxrb_block_items"><div class="dhxrb_big_button"><img class="dhxrb_image" src="vas/sms/images/load/senderid.png"><div class="dhxrb_label_button">Sender ID</div></div></div><div class="dhxrb_block_label">sender ID</div></div></div></div></div><div class="dhx_cell_tabbar" style="visibility: hidden; z-index: 0; left: 0px; top: -5000px; width: 1000px; height: 90px;"><div class="dhx_cell_cont_tabbar" style="left: 0px; top: 0px; width: 998px; height: 90px;"><div class="dhxrb_g_area"><div class="dhxrb_block_base"><div class="dhxrb_block_items"><div class="dhxrb_big_button"><img class="dhxrb_image" src="vas/sms/images/load/shortcode.png"><div class="dhxrb_label_button">Shortcode</div></div></div><div class="dhxrb_block_label">shortcode</div></div><div class="dhxrb_block_base"><div class="dhxrb_block_items"><div class="dhxrb_big_button"><img class="dhxrb_image" src="vas/sms/images/load/keys.png"><div class="dhxrb_label_button">Key List</div></div></div><div class="dhxrb_block_label">keys</div></div><div class="dhxrb_block_base"><div class="dhxrb_block_items"><div class="dhxrb_big_button"><img class="dhxrb_image" src="vas/sms/images/load/uploaddb.png"><div class="dhxrb_label_button">upload DB</div></div></div><div class="dhxrb_block_label">uploaddb</div></div><div class="dhxrb_block_base"><div class="dhxrb_block_items"><div class="dhxrb_big_button"><img class="dhxrb_image" src="vas/sms/images/load/scheme.png"><div class="dhxrb_label_button">Scheme</div></div></div><div class="dhxrb_block_label">scheme</div></div></div></div></div><div class="dhx_cell_tabbar" style="visibility: hidden; z-index: 0; left: 0px; top: -5000px; width: 1000px; height: 90px;"><div class="dhx_cell_cont_tabbar" style="left: 0px; top: 0px; width: 998px; height: 90px;"><div class="dhxrb_g_area"><div class="dhxrb_block_base"><div class="dhxrb_block_items"><div class="dhxrb_big_button"><img class="dhxrb_image" src="vas/sms/images/load/reportsTran.png"><div class="dhxrb_label_button">Transaction</div></div><div class="dhxrb_big_button"><img class="dhxrb_image" src="vas/sms/images/load/creditreport.png"><div class="dhxrb_label_button">Credit</div></div><div class="dhxrb_big_button"><img class="dhxrb_image" src="vas/sms/images/load/sentbox.png"><div class="dhxrb_label_button">Sent</div></div></div><div class="dhxrb_block_label">push report</div></div><div class="dhxrb_block_base"><div class="dhxrb_block_items"><div class="dhxrb_big_button"><img class="dhxrb_image" src="vas/sms/images/load/pullreport.png"><div class="dhxrb_label_button">Report</div></div><div class="dhxrb_big_button"><img class="dhxrb_image" src="vas/sms/images/load/errorreport.png"><div class="dhxrb_label_button">Error</div></div><div class="dhxrb_big_button"><img class="dhxrb_image" src="vas/sms/images/load/feedback.png"><div class="dhxrb_label_button">Feedback</div></div></div><div class="dhxrb_block_label">pull report</div></div></div></div></div></div></div></div></div>
        <div id="toolbar" style="margin-top:5px;" dir="ltr" class="dhx_toolbar_dhx_skyblue dhxtoolbar_icons_18 displayOff"><div class="dhxtoolbar_float_left"><div class="dhx_toolbar_text" title="">Search By</div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/adduser.png"><div class="dhxtoolbar_text">Add User</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/userapprove.png"><div class="dhxtoolbar_text">Approve</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/usersuspend.png"><div class="dhxtoolbar_text">Suspend</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/edit.png"><div class="dhxtoolbar_text">Edit Privileges</div></div><div class="dhx_toolbar_text" title=""><div id="sortList" style="width:100px; height:18px;" margin-right="20px;"></div></div><div class="dhx_toolbar_text" title=""><div id="errsortList" style="width:100px; height:18px;" margin-right="20px;"></div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/assigngateway.png"><div class="dhxtoolbar_text">Add Gateway</div></div><div class="dhx_toolbar_text" title="">from &nbsp;&nbsp;<input style="font-size:11px;padding: 2px 5px;" id="from_calander" type="text" readonly=""></div><div class="dhx_toolbar_text" title="">till &nbsp;&nbsp;<input style="font-size:11px;padding: 2px 5px;" id="till_calander" type="text" readonly=""></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/senderid.png"><div class="dhxtoolbar_text">Add SenderID</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/package.png"><div class="dhxtoolbar_text">Add Package</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/assignshortcode.png"><div class="dhxtoolbar_text">Add shortcode</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/category.png"><div class="dhxtoolbar_text">Add Category</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/keys.png"><div class="dhxtoolbar_text">Add key</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/scheme.png"><div class="dhxtoolbar_text">Add Scheme</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/usergroup.png"><div class="dhxtoolbar_text">Add Group</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/prefix.png"><div class="dhxtoolbar_text">Add Prefix</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/operator.png"><div class="dhxtoolbar_text">Add Operator</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/country.png"><div class="dhxtoolbar_text">Add Country</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/features.png"><div class="dhxtoolbar_text">Add Feature</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/scheduler.png"><div class="dhxtoolbar_text">Add Schedule</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/template.png"><div class="dhxtoolbar_text">Add Template</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/adressbook.png"><div class="dhxtoolbar_text">Add Address Book</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/contact.png"><div class="dhxtoolbar_text">Add Contact</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/save_msg.png"><div class="dhxtoolbar_text">Add Message</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/block.png"><div class="dhxtoolbar_text">Add Cell No.</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/edit.png"><div class="dhxtoolbar_text">Edit</div></div><div class="dhx_toolbar_arw dhxtoolbar_btn_def" title=""><div class="arwimg">&nbsp;</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/edit.png"><div class="dhxtoolbar_text">Delete</div></div><div class="dhx_toolbar_arw dhxtoolbar_btn_def" title=""><div class="arwimg">&nbsp;</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/edit.png"><div class="dhxtoolbar_text">Edit</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/approve.png"><div class="dhxtoolbar_text">Approve</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/disapprove.png"><div class="dhxtoolbar_text">Disapprove</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/enable.png"><div class="dhxtoolbar_text">Enable</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/disable.png"><div class="dhxtoolbar_text">Disable</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/stopcron.png"><div class="dhxtoolbar_text">Stop Cron</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/resumecron.png"><div class="dhxtoolbar_text">Resume Cron</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/delete.png"><div class="dhxtoolbar_text">Delete</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/detail.png"><div class="dhxtoolbar_text">Today Report</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/upload.png"><div class="dhxtoolbar_text">Upload</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/detail.png"><div class="dhxtoolbar_text">Detail</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/detail.png"><div class="dhxtoolbar_text">Assign Details</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/empty.png"><div class="dhxtoolbar_text">Empty</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/selectall.png"><div class="dhxtoolbar_text">Select All</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/disselect.png"><div class="dhxtoolbar_text">Dis-select</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/excel.png"><div class="dhxtoolbar_text">Excel</div></div><div class="dhx_toolbar_btn dhxtoolbar_btn_def" title=""><img src="vas/sms/images/load/search.png"><div class="dhxtoolbar_text">Search</div></div></div></div>
        <div id="main_feild" style="width:930px;  margin:10px auto;">
        	<div id="ribbonState" class="ribbonUp"></div>
            <div id="dhxDynFeild" style="position: relative;"><div id="load" style="position: absolute; top: 0px; z-index: 2; left: 0px; height: 100%; width: 100%; background-color: rgba(31, 31, 31, 0.1); display: none;"><p style="text-align:center; margin:20% auto; padding:3px 40px 3px 0; background:url(vas/sms/images/load/loading.gif) no-repeat center center; background-size:20px 20px; background-position:80px 0; width:70px;">Loading...</p></div><div id="in_consdhxDynFeild" style="height: 100%; width: 100%; background-color: white;"><style>
#homeView{ height:490px; font-size:12px; width:100%;
background-color:#fbfbfb;
margin-top:15px;
}
#homeView h2{ font-size:15px; font-weight:normal; color:white;background-color:#0078d7;
-webkit-box-sizing: border-box;
-moz-box-sizing: border-box;
box-sizing: border-box;
padding:15px 15px;
}
#homeView h2 img{ vertical-align:middle; margin-right:10px; width:18px;}
.homeDiv{ margin:20px;}
#homeLeft{ width:550px; }
#homeRight{  width:320px; margin:20px 30px 0 0;}
#homeRight h3{font-size:14px;  padding-bottom:9px;
-webkit-box-sizing: border-box;
-moz-box-sizing: border-box;
box-sizing: border-box;

}
.homeDiv h3{ font-size:14px; color:black; padding-bottom:10px; margin-bottom:5px; border-bottom:1px solid #d1d1d1; }
.homeDiv h3 img, #homeRight h3 img{ vertical-align:middle; margin-right:10px; width:16px;}
.homeDiv table{ margin-left:30px;}
.homeDiv table tr td { padding:4px 5px; font-size:12px; color:#635f5f;}
.homeDiv table tr td:last-child { color:#0078d7;}
#homeNotification{ width:100%; height:320px; border:2px solid #c3c6c9; background-color:white;
padding:10px; overflow:auto;
-webkit-box-sizing: border-box;
-moz-box-sizing: border-box;
box-sizing: border-box;
}
#homeNotification ul { margin:0 0 0 10px;}
#homeNotification ul li { line-height:14px; font-size:11px; padding:3px 30px 3px 5px; list-style:circle; border:1px solid #d1d1d1; margin-bottom:5px;
position:relative;
}
#homeNotification ul li span{color:#6c6d6f; }
#homeNotification ul li img{ width:15px; position:absolute; right:5px; top:3px; cursor:pointer;}
#homeNotDelete { margin-top:10px;}
</style>

<div id="homeView">
	<h2><img src="vas/sms/images/load/enterhome.png">Welcome </h2>
    <div id="homeLeft" class="floatLeft">
        <div id="homeBalance" class="homeDiv">
            <h3><img src="vas/sms/images/load/homeBalance.png">Total Account balance till today </h3>
            <table>
            	<tbody><tr>
								<td>NTC [ Nepal Telecom Pvt. Ltd. ]</td>
								<td>: 27</td>
							</tr><tr>
								<td>AXIATA [ Axiata Pvt. Ltd ]</td>
								<td>: 10</td>
							</tr>
            </tbody></table>
        </div>
        <div id="homeTransaction" class="homeDiv">
            <h3><img src="vas/sms/images/load/homeTransaction.png">Today's Total Transaction </h3>
            <table>
            	<tbody><tr>
								<td>NTC [ Nepal Telecom Pvt. Ltd. ]</td>
								<td>: 000 </td>
							</tr><tr>
								<td>AXIATA [ Axiata Pvt. Ltd ]</td>
								<td>: 000 </td>
							</tr><tr>
								<td>SMARTCELL [ Smart Telecom Pvt. Ltd. ]</td>
								<td>: 000 </td>
							</tr>
            </tbody></table>
        </div>
        <div id="homeTransaction" class="homeDiv">
            <h3><img src="vas/sms/images/load/homeInfo.png">Account Informations </h3>
            <table>
                <tbody><tr>
                    <td>Organization Name</td>
                    <td> : Asdf</td>
                </tr>
                <tr>
                    <td>Email  </td>
                    <td> : faad@faf.com</td>
                </tr>
                <tr>
                    <td>Contact Person </td>
                    <td> : Hsjfhhfa</td>
                </tr>
                <tr>
                    <td>Mobile Number  </td>
                    <td> : 9876543212</td>
                </tr>
                <tr>
                    <td>Contact Number  </td>
                    <td> : 9876542112</td>
                </tr>
                <tr>
                    <td>Address  </td>
                    <td> : Bfhsff</td>
                </tr>

            </tbody></table>
        </div>
    </div>
    <div id="homeRight" class="floatRight">
    	<h3><img src="vas/sms/images/load/homeNotification.png">Quick Unseen Notification [ <span style="color:red;">within 7 days</span> ]</h3>
        <div id="homeNotification">
        	<ul>
            <p><span class="red">****</span> No Notification found for display <span class="red">****</span></p>
            </ul>

        </div>
        <button id="homeNotDelete" class="button"> Clear All</button>
    </div>
    <div class="clearBoth" style="height:0;"></div>
</div>
<script language="javascript" type="text/javascript">
$('#homeNotification ul li img').on('click',function(e){
	var notiId = $(this).parent('li').data('id');
	$('#dhxDynFeild div#load').show();
	var res = obj.dhx_ajax('vas/sms/common_c/noticeViewState/'+notiId );
	if(res=='sucess'){

		$(this).parent('li').remove();
		if($('#homeNotification ul li').length== 0){
			$('#homeNotification').append( '<p><span class="red">****</span> No Notification found for display <span class="red">****</span></p>');
		}
	}
	else{
		obj.message_show(res,'error');
	}

	setTimeout(function(){  $('#dhxDynFeild div#load').hide(); }, 900);
});
$('#homeNotDelete').on('click',function(e){
	var notiIdArr = [];
	if($('#homeNotification ul li').length== 0){
		obj.message_show('** : There is No Notification found');
	}else{
		$('#homeNotification ul li').each(function() {
			notiIdArr.push($(this).data('id'));
		});
		$('#dhxDynFeild div#load').show();
		var res = obj.dhx_ajax('vas/sms/common_c/noticeViewState/'+notiIdArr.join('_') );
		if(res=='sucess'){
			//obj.message_show('Operation Sucessfull');
			$('#homeNotification ul').empty();
			$('#homeNotification').append( '<p><span class="red">****</span> No Notification found for display <span class="red">****</span></p>');
		}
		else{
			obj.message_show(res,'error');
		}

		setTimeout(function(){  $('#dhxDynFeild div#load').hide(); }, 900);
	}
});
</script>
</div></div>
            <div id="extraData">
            </div>
        </div>
    </div>
