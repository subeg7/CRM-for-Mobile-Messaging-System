<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

////// admin login domain setting
$config['admin_login_domain'] = 'localhost:8888';
/// cron nonce
$config['cron_nonce'] = 'E2F6E4CA97947BDB';
$config['pull_nonce'] = 'P2FZX4CA93047BZB';

$config['subkey_category'] = array('vp','ptp');// all small letter



?>
