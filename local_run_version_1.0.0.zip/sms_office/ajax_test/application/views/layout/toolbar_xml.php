<script language="javascript" type="text/javascript">
 var toolbar_xml = '<?xml version="1.0"?><toolbar>'+
					'<item id="newuser" type="button" text="Add User" img="/adduser.png"/>'+
					'<item id="newgateway" type="button" text="Add Gateway" img="/assigngateway.png"/>'+
					'<item id="newsenderid" type="button" text="Add SenderID" img="/senderid.png"/>'+
					'<item id="newpackage" type="button" text="Add Package" img="/package.png"/>'+
					'<item id="newshortcode" type="button" text="Add shortcode" img="/assignshortcode.png"/>'+
					'<item id="newcategory" type="button" text="Add Category" img="/category.png"/>'+
					'<item id="newkey" type="button" text="Add key" img="/keys.png"/>'+
					'<item id="newscheme" type="button" text="Add Scheme" img="/scheme.png"/>'+
					'<item id="newgroup" type="button" text="Add Group" img="/usergroup.png"/>'+
					'<item id="newprefix" type="button" text="Add Prefix" img="/prefix.png"/>'+
					'<item id="newoperator" type="button" text="Add Operator" img="/operator.png"/>'+
					'<item id="newcountry" type="button" text="Add Country" img="/country.png"/>'+
					'<item id="newscheduler" type="button" text="Add Schedule" img="/scheduler.png"/>'+
					'<item id="newaddressbook" type="button" text="Add Address Book" img="/adressbook.png"/>'+
					'<item id="newcontact" type="button" text="Add Contact" img="/contact.png" />'+
					'<item id="newtemplate" type="button" text="Add Template" img="/template.png"/>'+
					'<item id="sep01" type="separator"/>'+
					'<item id="from" type="text" text="From"/>'+
					'<item id="from_date" type="buttonInput" value="Select Date" width="80" attribute ="readonly" />'+
					'<item id="Till" type="text" text="Till"/>'+
					'<item id="till_date" type="buttonInput" value="Select Date" width="80" attribute ="readonly" />'+

					'<item id="userapprove" type="button" text="Approve" img="/userapprove.png"/>'+
					'<item id="usersuspend" type="button" text="Suspend" img="/usersuspend.png"/>'+
					'<item id="approve" type="button" text="Approve" img="/approve.png"/>'+
					'<item id="disapprove" type="button" text="Disapprove" img="/disapprove.png" />'+
					'<item id="enable" type="button" text="Enable" img="/enable.png" />'+
					'<item id="disable" type="button" text="Disable" img="/disable.png" />'+
					'<item id="stopcron" type="button" text="Stop Cron" img="/stopcron.png" />'+
					'<item id="resumecron" type="button" text="Resume Cron" img="/resumecron.png" />'+
					'<item id="upload" type="button" text="Upload" img="/upload.png" />'+
					'<item id="sep01" type="separator"/>'+
					'<item id="detail" type="button" text="Detail" img="/detail.png" />'+
					'<item id="edit" type="button" text="Edit" img="/edit.png" />'+
					'<item id="aedit" type="buttonSelect" text="Edit" img="/edit.png">'+
						'<item type="button"	id="address_edit"  text="Address Book" img="/adressbook.png"/>'+
						'<item type="button"	id="contact_edit" text="Contact"    img="/contact.png"    />'+
					'</item>'+

					'<item id="delete" type="button" text="Delete" img="/delete.png" />'+
					'<item id="select" type="button" text="Select All" img="/selectall.png" />'+
					'<item id="disselect" type="button" text="Dis-select" img="/disselect.png" />'+
					'<item id="excel" type="button" text="Excel" img="/excel.png" />'+
					'<item id="search" type="button" text="Search" img="/search.png" />'+
				'</toolbar>';


</script>
